﻿namespace CalculatorApp
{
    partial class FRMCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PNLButtonGroup = new System.Windows.Forms.Panel();
            this.BTNClearAll = new System.Windows.Forms.Button();
            this.BTNClear = new System.Windows.Forms.Button();
            this.BTNDecimal = new System.Windows.Forms.Button();
            this.BTNSubtract = new System.Windows.Forms.Button();
            this.BTNAdd = new System.Windows.Forms.Button();
            this.BTNDivide = new System.Windows.Forms.Button();
            this.BTNSeven = new System.Windows.Forms.Button();
            this.BTNMultiply = new System.Windows.Forms.Button();
            this.BTNFour = new System.Windows.Forms.Button();
            this.BTNEight = new System.Windows.Forms.Button();
            this.BTNNine = new System.Windows.Forms.Button();
            this.BTNFive = new System.Windows.Forms.Button();
            this.BTNOne = new System.Windows.Forms.Button();
            this.BTNZero = new System.Windows.Forms.Button();
            this.BTNThree = new System.Windows.Forms.Button();
            this.BTNEquals = new System.Windows.Forms.Button();
            this.BTNSix = new System.Windows.Forms.Button();
            this.BTNTwo = new System.Windows.Forms.Button();
            this.PNLResultDisplay = new System.Windows.Forms.Panel();
            this.LBLResultsDisplay = new System.Windows.Forms.Label();
            this.LBLExpressionDisplay = new System.Windows.Forms.Label();
            this.PNLButtonGroup.SuspendLayout();
            this.PNLResultDisplay.SuspendLayout();
            this.SuspendLayout();
            // 
            // PNLButtonGroup
            // 
            this.PNLButtonGroup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PNLButtonGroup.Controls.Add(this.BTNClearAll);
            this.PNLButtonGroup.Controls.Add(this.BTNClear);
            this.PNLButtonGroup.Controls.Add(this.BTNDecimal);
            this.PNLButtonGroup.Controls.Add(this.BTNSubtract);
            this.PNLButtonGroup.Controls.Add(this.BTNAdd);
            this.PNLButtonGroup.Controls.Add(this.BTNDivide);
            this.PNLButtonGroup.Controls.Add(this.BTNSeven);
            this.PNLButtonGroup.Controls.Add(this.BTNMultiply);
            this.PNLButtonGroup.Controls.Add(this.BTNFour);
            this.PNLButtonGroup.Controls.Add(this.BTNEight);
            this.PNLButtonGroup.Controls.Add(this.BTNNine);
            this.PNLButtonGroup.Controls.Add(this.BTNFive);
            this.PNLButtonGroup.Controls.Add(this.BTNOne);
            this.PNLButtonGroup.Controls.Add(this.BTNZero);
            this.PNLButtonGroup.Controls.Add(this.BTNThree);
            this.PNLButtonGroup.Controls.Add(this.BTNEquals);
            this.PNLButtonGroup.Controls.Add(this.BTNSix);
            this.PNLButtonGroup.Controls.Add(this.BTNTwo);
            this.PNLButtonGroup.Location = new System.Drawing.Point(12, 71);
            this.PNLButtonGroup.MaximumSize = new System.Drawing.Size(213, 228);
            this.PNLButtonGroup.MinimumSize = new System.Drawing.Size(213, 228);
            this.PNLButtonGroup.Name = "PNLButtonGroup";
            this.PNLButtonGroup.Size = new System.Drawing.Size(213, 228);
            this.PNLButtonGroup.TabIndex = 0;
            // 
            // BTNClearAll
            // 
            this.BTNClearAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNClearAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNClearAll.Location = new System.Drawing.Point(162, 3);
            this.BTNClearAll.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNClearAll.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNClearAll.Name = "BTNClearAll";
            this.BTNClearAll.Size = new System.Drawing.Size(48, 39);
            this.BTNClearAll.TabIndex = 0;
            this.BTNClearAll.TabStop = false;
            this.BTNClearAll.Text = "CE";
            this.BTNClearAll.UseVisualStyleBackColor = true;
            this.BTNClearAll.Click += new System.EventHandler(this.BTNClearAll_Click);
            // 
            // BTNClear
            // 
            this.BTNClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNClear.Location = new System.Drawing.Point(162, 48);
            this.BTNClear.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNClear.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNClear.Name = "BTNClear";
            this.BTNClear.Size = new System.Drawing.Size(48, 39);
            this.BTNClear.TabIndex = 14;
            this.BTNClear.TabStop = false;
            this.BTNClear.Text = "C";
            this.BTNClear.UseVisualStyleBackColor = true;
            this.BTNClear.Click += new System.EventHandler(this.BTNClear_Click);
            // 
            // BTNDecimal
            // 
            this.BTNDecimal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNDecimal.Location = new System.Drawing.Point(111, 138);
            this.BTNDecimal.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNDecimal.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNDecimal.Name = "BTNDecimal";
            this.BTNDecimal.Size = new System.Drawing.Size(48, 39);
            this.BTNDecimal.TabIndex = 5;
            this.BTNDecimal.TabStop = false;
            this.BTNDecimal.Text = ".";
            this.BTNDecimal.UseVisualStyleBackColor = true;
            this.BTNDecimal.Click += new System.EventHandler(this.BTNDecimal_Click);
            // 
            // BTNSubtract
            // 
            this.BTNSubtract.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNSubtract.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNSubtract.Location = new System.Drawing.Point(162, 138);
            this.BTNSubtract.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNSubtract.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNSubtract.Name = "BTNSubtract";
            this.BTNSubtract.Size = new System.Drawing.Size(48, 39);
            this.BTNSubtract.TabIndex = 6;
            this.BTNSubtract.TabStop = false;
            this.BTNSubtract.Text = "-";
            this.BTNSubtract.UseVisualStyleBackColor = true;
            this.BTNSubtract.Click += new System.EventHandler(this.BTNSubtract_Click);
            // 
            // BTNAdd
            // 
            this.BTNAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNAdd.Location = new System.Drawing.Point(162, 184);
            this.BTNAdd.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNAdd.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNAdd.Name = "BTNAdd";
            this.BTNAdd.Size = new System.Drawing.Size(48, 39);
            this.BTNAdd.TabIndex = 3;
            this.BTNAdd.TabStop = false;
            this.BTNAdd.Text = "+";
            this.BTNAdd.UseVisualStyleBackColor = true;
            this.BTNAdd.Click += new System.EventHandler(this.BTNAdd_Click);
            // 
            // BTNDivide
            // 
            this.BTNDivide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNDivide.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNDivide.Location = new System.Drawing.Point(111, 184);
            this.BTNDivide.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNDivide.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNDivide.Name = "BTNDivide";
            this.BTNDivide.Size = new System.Drawing.Size(48, 39);
            this.BTNDivide.TabIndex = 2;
            this.BTNDivide.TabStop = false;
            this.BTNDivide.Text = "/";
            this.BTNDivide.UseVisualStyleBackColor = true;
            this.BTNDivide.Click += new System.EventHandler(this.BTNDivide_Click);
            // 
            // BTNSeven
            // 
            this.BTNSeven.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNSeven.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNSeven.Location = new System.Drawing.Point(4, 3);
            this.BTNSeven.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNSeven.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNSeven.Name = "BTNSeven";
            this.BTNSeven.Size = new System.Drawing.Size(48, 39);
            this.BTNSeven.TabIndex = 15;
            this.BTNSeven.TabStop = false;
            this.BTNSeven.Text = "7";
            this.BTNSeven.UseVisualStyleBackColor = true;
            this.BTNSeven.Click += new System.EventHandler(this.BTNSeven_Click);
            // 
            // BTNMultiply
            // 
            this.BTNMultiply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNMultiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNMultiply.Location = new System.Drawing.Point(162, 93);
            this.BTNMultiply.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNMultiply.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNMultiply.Name = "BTNMultiply";
            this.BTNMultiply.Size = new System.Drawing.Size(48, 39);
            this.BTNMultiply.TabIndex = 10;
            this.BTNMultiply.TabStop = false;
            this.BTNMultiply.Text = "*";
            this.BTNMultiply.UseVisualStyleBackColor = true;
            this.BTNMultiply.Click += new System.EventHandler(this.BTNMultiply_Click);
            // 
            // BTNFour
            // 
            this.BTNFour.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNFour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNFour.Location = new System.Drawing.Point(4, 48);
            this.BTNFour.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNFour.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNFour.Name = "BTNFour";
            this.BTNFour.Size = new System.Drawing.Size(48, 39);
            this.BTNFour.TabIndex = 11;
            this.BTNFour.TabStop = false;
            this.BTNFour.Text = "4";
            this.BTNFour.UseVisualStyleBackColor = true;
            this.BTNFour.Click += new System.EventHandler(this.BTNFour_Click);
            // 
            // BTNEight
            // 
            this.BTNEight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNEight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNEight.Location = new System.Drawing.Point(57, 3);
            this.BTNEight.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNEight.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNEight.Name = "BTNEight";
            this.BTNEight.Size = new System.Drawing.Size(48, 39);
            this.BTNEight.TabIndex = 16;
            this.BTNEight.TabStop = false;
            this.BTNEight.Text = "8";
            this.BTNEight.UseVisualStyleBackColor = true;
            this.BTNEight.Click += new System.EventHandler(this.BTNEight_Click);
            // 
            // BTNNine
            // 
            this.BTNNine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNNine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNNine.Location = new System.Drawing.Point(111, 3);
            this.BTNNine.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNNine.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNNine.Name = "BTNNine";
            this.BTNNine.Size = new System.Drawing.Size(48, 39);
            this.BTNNine.TabIndex = 17;
            this.BTNNine.TabStop = false;
            this.BTNNine.Text = "9";
            this.BTNNine.UseVisualStyleBackColor = true;
            this.BTNNine.Click += new System.EventHandler(this.BTNNine_Click);
            // 
            // BTNFive
            // 
            this.BTNFive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNFive.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNFive.Location = new System.Drawing.Point(57, 48);
            this.BTNFive.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNFive.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNFive.Name = "BTNFive";
            this.BTNFive.Size = new System.Drawing.Size(48, 39);
            this.BTNFive.TabIndex = 12;
            this.BTNFive.TabStop = false;
            this.BTNFive.Text = "5";
            this.BTNFive.UseVisualStyleBackColor = true;
            this.BTNFive.Click += new System.EventHandler(this.BTNFive_Click);
            // 
            // BTNOne
            // 
            this.BTNOne.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNOne.Location = new System.Drawing.Point(4, 93);
            this.BTNOne.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNOne.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNOne.Name = "BTNOne";
            this.BTNOne.Size = new System.Drawing.Size(48, 39);
            this.BTNOne.TabIndex = 7;
            this.BTNOne.TabStop = false;
            this.BTNOne.Text = "1";
            this.BTNOne.UseVisualStyleBackColor = true;
            this.BTNOne.Click += new System.EventHandler(this.BTNOne_Click);
            // 
            // BTNZero
            // 
            this.BTNZero.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNZero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNZero.Location = new System.Drawing.Point(5, 138);
            this.BTNZero.MaximumSize = new System.Drawing.Size(101, 39);
            this.BTNZero.MinimumSize = new System.Drawing.Size(101, 39);
            this.BTNZero.Name = "BTNZero";
            this.BTNZero.Size = new System.Drawing.Size(101, 39);
            this.BTNZero.TabIndex = 4;
            this.BTNZero.TabStop = false;
            this.BTNZero.Text = "0";
            this.BTNZero.UseVisualStyleBackColor = true;
            this.BTNZero.Click += new System.EventHandler(this.BTNZero_Click);
            // 
            // BTNThree
            // 
            this.BTNThree.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BTNThree.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNThree.Location = new System.Drawing.Point(111, 93);
            this.BTNThree.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNThree.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNThree.Name = "BTNThree";
            this.BTNThree.Size = new System.Drawing.Size(48, 39);
            this.BTNThree.TabIndex = 9;
            this.BTNThree.TabStop = false;
            this.BTNThree.Text = "3";
            this.BTNThree.UseVisualStyleBackColor = true;
            this.BTNThree.Click += new System.EventHandler(this.BTNThree_Click);
            // 
            // BTNEquals
            // 
            this.BTNEquals.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNEquals.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNEquals.Location = new System.Drawing.Point(4, 184);
            this.BTNEquals.MaximumSize = new System.Drawing.Size(102, 39);
            this.BTNEquals.MinimumSize = new System.Drawing.Size(102, 39);
            this.BTNEquals.Name = "BTNEquals";
            this.BTNEquals.Size = new System.Drawing.Size(102, 39);
            this.BTNEquals.TabIndex = 0;
            this.BTNEquals.TabStop = false;
            this.BTNEquals.Text = "=";
            this.BTNEquals.UseVisualStyleBackColor = true;
            this.BTNEquals.Click += new System.EventHandler(this.BTNEquals_Click);
            // 
            // BTNSix
            // 
            this.BTNSix.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNSix.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNSix.Location = new System.Drawing.Point(111, 48);
            this.BTNSix.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNSix.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNSix.Name = "BTNSix";
            this.BTNSix.Size = new System.Drawing.Size(48, 39);
            this.BTNSix.TabIndex = 13;
            this.BTNSix.TabStop = false;
            this.BTNSix.Text = "6";
            this.BTNSix.UseVisualStyleBackColor = true;
            this.BTNSix.Click += new System.EventHandler(this.BTNSix_Click);
            // 
            // BTNTwo
            // 
            this.BTNTwo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNTwo.Location = new System.Drawing.Point(57, 93);
            this.BTNTwo.MaximumSize = new System.Drawing.Size(48, 39);
            this.BTNTwo.MinimumSize = new System.Drawing.Size(48, 39);
            this.BTNTwo.Name = "BTNTwo";
            this.BTNTwo.Size = new System.Drawing.Size(48, 39);
            this.BTNTwo.TabIndex = 8;
            this.BTNTwo.TabStop = false;
            this.BTNTwo.Text = "2";
            this.BTNTwo.UseVisualStyleBackColor = true;
            this.BTNTwo.Click += new System.EventHandler(this.BTNTwo_Click);
            // 
            // PNLResultDisplay
            // 
            this.PNLResultDisplay.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PNLResultDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PNLResultDisplay.Controls.Add(this.LBLResultsDisplay);
            this.PNLResultDisplay.Controls.Add(this.LBLExpressionDisplay);
            this.PNLResultDisplay.Location = new System.Drawing.Point(12, 12);
            this.PNLResultDisplay.MaximumSize = new System.Drawing.Size(213, 53);
            this.PNLResultDisplay.MinimumSize = new System.Drawing.Size(213, 53);
            this.PNLResultDisplay.Name = "PNLResultDisplay";
            this.PNLResultDisplay.Size = new System.Drawing.Size(213, 53);
            this.PNLResultDisplay.TabIndex = 1;
            // 
            // LBLResultsDisplay
            // 
            this.LBLResultsDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLResultsDisplay.Location = new System.Drawing.Point(0, 30);
            this.LBLResultsDisplay.MaximumSize = new System.Drawing.Size(213, 23);
            this.LBLResultsDisplay.MinimumSize = new System.Drawing.Size(213, 23);
            this.LBLResultsDisplay.Name = "LBLResultsDisplay";
            this.LBLResultsDisplay.Size = new System.Drawing.Size(213, 23);
            this.LBLResultsDisplay.TabIndex = 1;
            this.LBLResultsDisplay.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // LBLExpressionDisplay
            // 
            this.LBLExpressionDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLExpressionDisplay.Location = new System.Drawing.Point(0, 0);
            this.LBLExpressionDisplay.MaximumSize = new System.Drawing.Size(213, 23);
            this.LBLExpressionDisplay.MinimumSize = new System.Drawing.Size(213, 23);
            this.LBLExpressionDisplay.Name = "LBLExpressionDisplay";
            this.LBLExpressionDisplay.Size = new System.Drawing.Size(213, 23);
            this.LBLExpressionDisplay.TabIndex = 0;
            this.LBLExpressionDisplay.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // FRMCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(237, 311);
            this.Controls.Add(this.PNLResultDisplay);
            this.Controls.Add(this.PNLButtonGroup);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MaximumSize = new System.Drawing.Size(253, 349);
            this.MinimumSize = new System.Drawing.Size(253, 349);
            this.Name = "FRMCalculator";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.FRMCalculator_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FRMCalculator_KeyDown);
            this.PNLButtonGroup.ResumeLayout(false);
            this.PNLResultDisplay.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PNLButtonGroup;
        private System.Windows.Forms.Panel PNLResultDisplay;
        private System.Windows.Forms.Label LBLResultsDisplay;
        private System.Windows.Forms.Label LBLExpressionDisplay;
        private System.Windows.Forms.Button BTNSubtract;
        private System.Windows.Forms.Button BTNAdd;
        private System.Windows.Forms.Button BTNDivide;
        private System.Windows.Forms.Button BTNSeven;
        private System.Windows.Forms.Button BTNMultiply;
        private System.Windows.Forms.Button BTNFour;
        private System.Windows.Forms.Button BTNEight;
        private System.Windows.Forms.Button BTNNine;
        private System.Windows.Forms.Button BTNFive;
        private System.Windows.Forms.Button BTNOne;
        private System.Windows.Forms.Button BTNZero;
        private System.Windows.Forms.Button BTNThree;
        private System.Windows.Forms.Button BTNEquals;
        private System.Windows.Forms.Button BTNSix;
        private System.Windows.Forms.Button BTNTwo;
        private System.Windows.Forms.Button BTNDecimal;
        private System.Windows.Forms.Button BTNClearAll;
        private System.Windows.Forms.Button BTNClear;
    }
}

