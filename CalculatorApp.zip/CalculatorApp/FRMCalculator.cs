﻿/* Title: Simple Calculator
 * By:Davis Kieu
 * Date:11/11/2018
 * Description: A simple calculator that enables the user to perform simple arithmetic calculations.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorApp
{

    public partial class FRMCalculator : Form
    {
        const string DIVIDE_BY_ZERO_ERROR = "Cannot divide by zero";
        const string GENERAL_ERROR = "Error";
        const string INVALID_ERROR = "Invalid Expression";

        private string strExpression;

        public FRMCalculator()
        {
            InitializeComponent();
        }        

        private void FRMCalculator_Load(object sender, EventArgs e)
        {
            LBLExpressionDisplay.Text = "";
            strExpression = "";
        }

        private void BTNZero_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "0";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNOne_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "1";
            
            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNTwo_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "2";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNThree_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "3";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNFour_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "4";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNFive_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "5";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNSix_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "6";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNSeven_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "7";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNEight_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "8";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void FRMCalculator_KeyDown(object sender, KeyEventArgs e)
        {
            Keys key = e.KeyCode;
        
            if (key == Keys.D0 || key == Keys.NumPad0)
                BTNZero_Click(sender, e);
            else if (key == Keys.D1 || key == Keys.NumPad1)
                BTNOne_Click(sender, e);
            else if (key == Keys.D2 || key == Keys.NumPad2)
                BTNTwo_Click(sender, e);
            else if (key == Keys.D3 || key == Keys.NumPad3)
                BTNThree_Click(sender, e);
            else if (key == Keys.D4 || key == Keys.NumPad4)
                BTNFour_Click(sender, e);
            else if (key == Keys.D5 || key == Keys.NumPad5)
                BTNFive_Click(sender, e);
            else if (key == Keys.D6 || key == Keys.NumPad6)
                BTNSix_Click(sender, e);
            else if (key == Keys.D7 || key == Keys.NumPad7)
                BTNSeven_Click(sender, e);
            else if (key == Keys.D8 || key == Keys.NumPad8)
                BTNEight_Click(sender, e);
            else if (key == Keys.D9 || key == Keys.NumPad9)
                BTNNine_Click(sender, e);
            else
            {
                if (key == Keys.Enter)
                    BTNEquals_Click(sender, e);
                else if (key == Keys.Back)
                    BTNClear_Click(sender, e);
                else if (key == Keys.Divide)
                    BTNDivide_Click(sender, e);
                else if (key == Keys.Multiply)
                    BTNMultiply_Click(sender, e);
                else if (key == Keys.Decimal)
                    BTNDecimal_Click(sender, e);
                else if (key == Keys.Add)
                    BTNAdd_Click(sender, e);
                else if (key == Keys.Subtract)
                    BTNSubtract_Click(sender, e);
            }



        }

        private void BTNDivide_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "/";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNDecimal_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += ".";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNSubtract_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "-";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNMultiply_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "*";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNAdd_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "+";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNEquals_Click(object sender, EventArgs e)
        {
            strExpression = LBLExpressionDisplay.Text;

            //Regex pattern validates the user string representation of the expression
            if (Regex.IsMatch(strExpression, @"^([0-9]+\.?[0-9]*[+-/*])*[0-9]+\.?[0-9]*$"))
            {                
                //DataTable object is used to evaluate the string expression through its compute method.
                DataTable dt = new DataTable();
                try
                {
                    Object results = dt.Compute(strExpression, "");
                    LBLResultsDisplay.Text = results.ToString();
                }
                catch(DivideByZeroException)
                {
                    LBLResultsDisplay.Text = DIVIDE_BY_ZERO_ERROR;
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Unknown bug: " + ex.Message);
                }
            }
            else
                LBLResultsDisplay.Text = INVALID_ERROR;

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNClearAll_Click(object sender, EventArgs e)
        {
            clearDisplay();

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNClear_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();
            else
            {
                LBLResultsDisplay.Text = "";
                string expression = LBLExpressionDisplay.Text;

                if (expression.Length != 0)
                    LBLExpressionDisplay.Text = expression.Substring(0, expression.Length - 1);
            }

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void BTNNine_Click(object sender, EventArgs e)
        {
            string results = LBLResultsDisplay.Text;
            if (results == GENERAL_ERROR || results == INVALID_ERROR)
                clearDisplay();

            LBLExpressionDisplay.Text += "9";

            //Focus to label as a wrap-around solution to having no buttons with focus.
            LBLResultsDisplay.Focus();
        }

        private void clearDisplay()
        {
            LBLResultsDisplay.Text = "";
            LBLExpressionDisplay.Text = "";
        }
      




    }
}
